package fortEndPackage;

public class Guru_Fruits_Shop_ManagementMain {
	

	public static void main(String[] args) {
		
		User_Interface user_Interface=new User_Interface();
		user_Interface.userInterface();
	}

}
