package backEndPackage;

public class AddNewFruitsPOJO {
private String nameOfFruit;
private int qty;
private String unit; 
private int price;
private String date;


public String getNameOfFruit() {
	return nameOfFruit;
		
}
public void setNameOfFruit(String nameOfFruit) {
	this.nameOfFruit=nameOfFruit;
}
public int getQty() {
	return qty;
		
}
public void setQty(int qty) {
	this.qty=qty;
}

public String getUnit() {
	return unit;
}
public void setUnit(String unit) {
	this.unit=unit;
}
public int getPrice() {
	return price;
		
}
public void setPrice(int price) {
	this.price=price;
}
public String getdate() {
	return date;
}
public void setdate(String date) {
	this.date=date;
}
}
